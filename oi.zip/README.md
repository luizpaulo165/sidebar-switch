# Switch Sidebar for Right side - [Brackets](http://brackets.io)

![captura de tela 2017-09-04 as 9 33 42 am](https://user-images.githubusercontent.com/573227/30026655-3bccf376-9154-11e7-8f48-81b8f8239c75.png)

## Install

1. Open Brackets
2. Open the Extension Manager
3. Search for "Sidebar Switch"
4. Click "Install"

## Bugs

Repost in issues:[->](https://github.com/luizpaulo165/sidebar-switch/issues)

## License

[MIT License](./LICENSE)
